package com.amwa.core.utils

object Constants {

    const val BASE_URL = "https://api.spoonacular.com/"
    const val INGREDIENT_IMG_BASE_URL = "https://spoonacular.com/cdn/ingredients_100x100/"
}
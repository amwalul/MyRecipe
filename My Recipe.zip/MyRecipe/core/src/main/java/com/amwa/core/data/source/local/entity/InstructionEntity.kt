package com.amwa.core.data.source.local.entity

data class InstructionEntity(
    val number: Int,
    val step: String
)
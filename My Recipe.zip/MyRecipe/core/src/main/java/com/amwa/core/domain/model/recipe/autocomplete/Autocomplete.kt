package com.amwa.core.domain.model.recipe.autocomplete

data class Autocomplete(val id: Int)